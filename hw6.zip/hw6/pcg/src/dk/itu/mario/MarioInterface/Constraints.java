package dk.itu.mario.MarioInterface;

public interface Constraints {
	// the submitted level should has exactly the following information
	public  static int levelWidth= 320;
	public  static int gaps = 10;
	public  static int turtels = 7;
	public  static int coinBlocks = 10;
	
}
