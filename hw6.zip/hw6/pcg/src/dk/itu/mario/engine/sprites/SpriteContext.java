package dk.itu.mario.engine.sprites;

/**
 * <p>Title: </p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2010</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
public interface SpriteContext {
    public void addSprite(Sprite sprite);
    public void removeSprite(Sprite sprite);
}
