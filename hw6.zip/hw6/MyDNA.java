package dk.itu.mario.engine.level;

import java.util.Random;
import java.util.*;

//Make any new member variables and functions you deem necessary.
//Make new constructors if necessary
//You must implement mutate() and crossover()


public class MyDNA extends DNA
{
	
	public int numGenes = 0; //number of genes
	private Random random = new Random();

	// Return a new DNA that differs from this one in a small way.
	// Do not change this DNA by side effect; copy it, change the copy, and return the copy.
	public MyDNA mutate ()
	{
		MyDNA copy = new MyDNA();
		//YOUR CODE GOES BELOW HERE
//		System.out.println("Mutating");
		String oldChromosome = this.getChromosome();
		// change one letter
		int randnum = random.nextInt(6);
		char c;
		if (randnum == 0){
			c = 'g';
		} else if (randnum == 1) {
			c = 's';
		} else if (randnum == 2) {
			c = 'e';
		} else if (randnum == 3){
			c = 'c';
		} else if (randnum == 4){
			c = 'u';
		} else {
			c = 'd';
		}
		int randIndx = random.nextInt(oldChromosome.length());
		String newChromosome = oldChromosome.substring(0, randIndx) + c + oldChromosome.substring(randIndx+1);
		copy.setChromosome(newChromosome);
//		System.out.println("c: " + c);
//		System.out.println("randIndx: " + randIndx);
//		System.out.println("Old chrom: " + oldChromosome);
//		System.out.println("New chrom: " + newChromosome);
		//YOUR CODE GOES ABOVE HERE
		return copy;
	}
	
	// Do not change this DNA by side effect
	public ArrayList<MyDNA> crossover (MyDNA mate)
	{
		ArrayList<MyDNA> offspring = new ArrayList<MyDNA>();
		//YOUR CODE GOES BELOW HERE
//		System.out.println("crossover");
		String chrom1 = this.getChromosome();
//		System.out.println("c1: " + chrom1);
		String chrom2 = mate.getChromosome();
//		System.out.println("c2: " + chrom2);
		int randIndx = random.nextInt(chrom1.length()-2) + 1; // exclude beginning and end indx
//		System.out.println("randIndx: " + randIndx);
		MyDNA os1 = new MyDNA();
		String str = chrom1.substring(0, randIndx) + chrom2.substring(randIndx);
//		System.out.println("s1: " + str);
		os1.setChromosome(str);
		offspring.add(os1);
		MyDNA os2 = new MyDNA();
		str = chrom2.substring(0, randIndx) + chrom1.substring(randIndx);
//		System.out.println("s2: " + str);
		os2.setChromosome(str);
		offspring.add(os2);

		//YOUR CODE GOES ABOVE HERE
		return offspring;
	}
	
	// Optional, modify this function if you use a means of calculating fitness other than using the fitness member variable.
	// Return 0 if this object has the same fitness as other.
	// Return -1 if this object has lower fitness than other.
	// Return +1 if this objet has greater fitness than other.
	public int compareTo(MyDNA other)
	{
		int result = super.compareTo(other);
		//YOUR CODE GOES BELOW HERE
		
		//YOUR CODE GOES ABOVE HERE
		return result;
	}
	
	
	// For debugging purposes (optional)
	public String toString ()
	{
		String s = super.toString();
		//YOUR CODE GOES BELOW HERE
		
		//YOUR CODE GOES ABOVE HERE
		return s;
	}
	
	public void setNumGenes (int n)
	{
		this.numGenes = n;
	}

}

